from setuptools import setup, find_packages

setup(name='supply_core',
      version='0.1',
      description='Package with the uses cases',
      url='',
      author='TechTeam',
      author_email='javieremiliano1996@gmail.com',
      license='',
      packages=find_packages(),
      zip_safe=False)
